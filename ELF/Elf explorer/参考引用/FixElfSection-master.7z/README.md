# FixElfSection
用于dump elf文件后的section修复，修复后可以再IDA中直接查看


增加了 64 位系统的支持，但是还没测试
